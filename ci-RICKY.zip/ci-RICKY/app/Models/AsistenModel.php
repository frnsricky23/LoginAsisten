<?php

namespace App\Models;

use CodeIgniter\Model;

class AsistenModel extends Model
{
    protected $table = 'asisten';



    public function getAllAsisten()
    {
        return $this->findAll();
    }


    protected $allowedFields = ['nim', 'nama', "praktikum", "ipk"];
    public function simpan($record)
    {
        $this->insert($record);
    }


    public function ambil($nim)
    {

        return $this->where(['nim' => $nim])->first();
    }

    public function hapus($nim)
    {
        $this->where(['nim' => $nim])->delete();
    }
    protected $primaryKey = 'nim'; // Kolom yang menjadi primary key
    public function ubah($nim, $data)
    {
        $this->update($nim, $data);
    }
}
